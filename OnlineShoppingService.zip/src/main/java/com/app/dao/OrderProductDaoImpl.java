package com.app.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.app.pojos.OrderProduct;

@Repository
public class OrderProductDaoImpl implements IOrderProductDao {
	@PersistenceContext
	private EntityManager mgr;

	@Override
	public String addOrderProduct(OrderProduct op) {
		String mesg = "OrderProduct addition Successful";
		mgr.persist(op);
		return mesg;
	}

	@Override
	public OrderProduct getOrderProductDetails(int oprodId) {
		return mgr.find(OrderProduct.class, oprodId);
	}

}
