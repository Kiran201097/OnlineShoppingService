package com.app.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.app.pojos.OrderDetails;

@Repository
public class OrderDetailsDaoImpl implements IOrderDetailsDao {
	@PersistenceContext
	private EntityManager mgr;

	@Override
	public String addOrderDetails(OrderDetails od) {
		String mesg = "Order Details added successfully";
		mgr.persist(od);
		return mesg;
	}

	@Override
	public List<OrderDetails> getAllProducts() {
		String jpql = "select p from OrderDetails p";
		return mgr.createQuery(jpql, OrderDetails.class).getResultList();
	}

	@Override
	public OrderDetails getOrderDetailsById(int id) {

		return mgr.find(OrderDetails.class, id);
	}

	@Override
	public String updateStatus(OrderDetails statusToUpdate) {
		String mesg = "Product Updated successfully";
		mgr.merge(statusToUpdate);
		return mesg;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OrderDetails> getOrderDetailsByEmail(String email) {

		String query = "select u from OrderDetails u where email=:email";
		List<OrderDetails> list;
		list = mgr.createNativeQuery(query, OrderDetails.class).setParameter("email", email).getResultList();
		return list;
	}

}
