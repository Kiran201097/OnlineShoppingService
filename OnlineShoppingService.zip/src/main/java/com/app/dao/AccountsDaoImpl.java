package com.app.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.app.pojos.Accounts;

@Repository
public class AccountsDaoImpl implements IAccountsDao {

	@PersistenceContext
	private EntityManager mgr;

	@Override
	public Accounts validateUser(Accounts user) {

		String query = "select * from accounts u where email='" + user.getEmail() + "' and password='"
				+ user.getPassword() + "'";
		Accounts u = null;
		try {
			u = (Accounts) mgr.createNativeQuery(query, Accounts.class).getSingleResult();
		} catch (Exception e) {

		}
		return u;
	}

	@Override
	public String addUser(Accounts transientAccount) {

		String mesg = "Successfully Register";
		mgr.persist(transientAccount);
		return mesg;

	}

}
