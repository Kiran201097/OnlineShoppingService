package com.app.dao;

import java.util.List;

import com.app.pojos.OrderDetails;

public interface IOrderDetailsDao {
	
	String addOrderDetails(OrderDetails od);

	OrderDetails getOrderDetailsById(int id);

	List<OrderDetails> getAllProducts();

	String updateStatus(OrderDetails statusToUpdate);

	List<OrderDetails> getOrderDetailsByEmail(String email);
}
