package com.app.dao;

import com.app.pojos.OrderProduct;

public interface IOrderProductDao {
	
	String addOrderProduct(OrderProduct op);

	OrderProduct getOrderProductDetails(int oprodId);
}
