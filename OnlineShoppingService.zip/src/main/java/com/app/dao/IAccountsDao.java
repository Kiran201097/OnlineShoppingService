package com.app.dao;

import com.app.pojos.Accounts;

public interface IAccountsDao {

	public String addUser(Accounts transientProduct);

	Accounts validateUser(Accounts user);
}
