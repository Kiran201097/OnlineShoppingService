package com.app.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.app.pojos.Product;

@Repository
public class ProductDaoImpl implements IProductDao {

	@PersistenceContext
	private EntityManager mgr;

	@Override
	public List<Product> getAllProducts() {
		String jpql = "select p from Product p";
		return mgr.createQuery(jpql, Product.class).getResultList();
	}

	@Override
	public String deleteProduct(int propductId) {
		String mesg = "product deletion failed";

		Product p = mgr.find(Product.class, propductId);
		if (p != null) {
			mgr.remove(p);
			mesg = "product deleted successfully";
		}
		return mesg;
	}

	@Override
	public String addProduct(Product transientProduct) {
		String mesg = "Product added successfully";
		mgr.persist(transientProduct);
		return mesg;
	}

	@Override
	public Product getProductDetails(int id) {

		return mgr.find(Product.class, id);
	}

	@Override
	public String updateProduct(Product productToUpdate) {
		String mesg = "Product Updated successfully";
		mgr.merge(productToUpdate);
		return mesg;
	}

	@Override
	public List<Product> getProductsByCategory(String category) {
		String query = "select p from Product p where category='" + category + "'";

		return mgr.createQuery(query, Product.class).getResultList();
	}

}
