package com.app.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Accounts;
import com.app.pojos.OrderProduct;
import com.app.pojos.Product;
import com.app.service.IOrderProductService;
import com.app.service.IProductService;

@Controller
@RequestMapping("/cart")
public class CartController {

	@Autowired
	private IProductService prodService;
	@Autowired
	private IOrderProductService opService;

	public CartController() {
		System.out.println("In constr  " + getClass());
	}

	@GetMapping("/addToCart")
	public String addToCart(@RequestParam int productid, @RequestParam int quantity, RedirectAttributes flashMap,
			HttpSession session) {
		System.out.println("add to cart ");
		Accounts u = (Accounts) session.getAttribute("userDetails");
		if (u == null)
			return "/user/login";

		OrderProduct op = new OrderProduct(productid, quantity);
		opService.addOrderProduct(op);
		System.out.println("user " + u);
		u.getCart().getProducts().add(op);
		System.out.println(u.getCart().getProducts());
		return "redirect:/product/customerview";
	}

	@GetMapping("/showcart")
	public String showCart(HttpSession session) {
		Accounts u = (Accounts) session.getAttribute("userDetails");
		if (u == null)
			return "/user/login";
		List<Product> products = new ArrayList<Product>();
		for (OrderProduct op : u.getCart().getProducts()) {
			products.add(prodService.getProductDetails(op.getProductid()));
		}
		session.setAttribute("list", products);

		return "/product/cart";
	}

	@GetMapping("/remove")
	public String removeFromCart(@RequestParam int oprodId, HttpSession session) {
		System.out.println("Remove from cart");
		Accounts u = (Accounts) session.getAttribute("userDetails");
		if (u == null)
			return "/user/login";
		OrderProduct op = opService.getOrderProductDetails(oprodId);
		System.out.println("remove " + op);
		System.out.println(u.getCart().getProducts().removeIf(p -> p.getId() == op.getId()));
		session.setAttribute("userDetails", u);
		Product prod = prodService.getProductDetails(op.getProductid());
		@SuppressWarnings("unchecked")
		List<Product> products = (List<Product>) session.getAttribute("list");
		System.out.println(products.removeIf(p -> p.getId() == prod.getId()));
		session.setAttribute("list", products);
		return "redirect:/cart/showcart";
	}
}
