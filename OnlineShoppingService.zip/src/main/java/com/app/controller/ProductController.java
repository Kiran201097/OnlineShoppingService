package com.app.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Accounts;
import com.app.pojos.Product;
import com.app.service.IProductService;

@Controller
@RequestMapping("/product")
public class ProductController {

	@Autowired
	private IProductService service;

	public ProductController() {
		System.out.println("in ctor of " + getClass().getName());
	}

	@GetMapping("/adminview")
	public String productIndex() {
		return "/product/adminview";
	}

	@GetMapping("/list")
	public String listProducts(Model map) {
		System.out.println("in list products " + map);
		map.addAttribute("product_list", service.getAllProducts());
		return "/product/list";
	}

	@GetMapping("/delete")
	public String deleteProduct(@RequestParam int prodId, RedirectAttributes flashMap) {
		System.out.println("in delete products");
		flashMap.addFlashAttribute("status", service.deleteProduct(prodId));
		return "redirect:/product/list";// D.S : response.sendRedirect(response.encodeRedirectURL("/product/list"))
	}

	@GetMapping("/add")
	public String showAddProductForm(Product p) {
		System.out.println("in show product form ");
		return "/product/add";
	}

	@PostMapping("/add")
	public String processAddProductForm(Product transientPopulatedProduct, RedirectAttributes flashMap) {
		System.out.println("in process form " + transientPopulatedProduct);
		flashMap.addFlashAttribute("status", service.addProduct(transientPopulatedProduct));
		return "redirect:/product/list";
	}

	@GetMapping("/update/{id}")
	public String showUpdateForm(@PathVariable int id, Model map, Product product) {
		map.addAttribute("product", service.getProductDetails(id));
		return "/product/update";
	}

	@PostMapping("/update/{id}")
	public String updateProductDetails(@ModelAttribute Product product, Model map) {
		System.out.println("in update emp ");
		System.out.println(product);
		// check if emp exists
		service.updateProduct(product.getId(), product);
		return "redirect:/product/list";
	}

	@GetMapping("/byCategory")
	public String showProductByCategory(@RequestParam String category, Model map, HttpSession session) {
		Accounts u = (Accounts) session.getAttribute("userDetails");
		if (u == null)
			return "/user/login";
		map.addAttribute("product_list", service.getProductsByCategory(category));
		System.out.println(service.getProductsByCategory(category));

		if (category.contentEquals("menshoes"))
			return "/product/maleshoelist";

		else if (category.contentEquals("womenshoes"))
			return "/product/femaleshoelist";

		else if (category.contentEquals("watch"))
			return "/product/watches";

		else if (category.contentEquals("menshirts"))
			return "/product/tshirtlistmen";

		else if (category.contentEquals("womentop"))
			return "/product/toplistfemale";

		else if (category.contentEquals("cloths"))
			return "/product/cloths";

		else if (category.contentEquals("shoes"))
			return "/product/shoes";

		else
			return "/product/customerProdlist";
	}

	@GetMapping("/customerview")
	public String ShowProducts(Model map) {
		System.out.println("in list products " + map);
		map.addAttribute("product_list", service.getAllProducts());
		return "/product/customerProdlist";
	}

	@GetMapping("/customerProdlist")
	public String ShowCustomerView(Model map) {

		return "/product/customerProdlist";
	}

	@GetMapping("/contactus")
	public String ShowContactus(Model map) {

		return "/product/contactus";
	}

//	-----------------------------------------------PRODUCT--------------------------------------------------------------

	@GetMapping("/product1/{id}")
	public String ShowProduct1(@PathVariable int id, Model map, HttpSession session) {
		Accounts u = (Accounts) session.getAttribute("userDetails");
		if (u == null)
			return "/userRegister/login";
		map.addAttribute("product", service.getProductDetails(id));
		return "/product/product1";
	}

	@GetMapping("/product2")
	public String ShowProduct2(Model map) {

		return "/product/product2";
	}

	@GetMapping("/product3")
	public String ShowProduct3(Model map) {

		return "/product/product3";
	}

	@GetMapping("/product4")
	public String ShowProduct4(Model map) {

		return "/product/product4";
	}

	@GetMapping("/product5")
	public String ShowProduct5(Model map) {

		return "/product/product5";
	}

	@GetMapping("/product6")
	public String ShowProduct6(Model map) {

		return "/product/product6";
	}

	@GetMapping("/product7")
	public String ShowProduct7(Model map) {

		return "/product/product7";
	}

	@GetMapping("/product8")
	public String ShowProduct8(Model map) {

		return "/product/product8";
	}

	@GetMapping("/product9")
	public String ShowProduct9(Model map) {

		return "/product/product9";
	}

	@GetMapping("/productlt2")
	public String ShowProductlt2(Model map) {

		return "/product/productlt2";
	}

//	------------------------------------------------------------LISTS------------------------------------------------------
	@GetMapping("/tshirtlistmen")
	public String ShowTshirtListMen(Model map) {

		return "/product/tshirtlistmen";
	}

	@GetMapping("/toplistfemale")
	public String ShowTopListFemale(Model map) {

		return "/product/toplistfemale";
	}

	@GetMapping("/watches")
	public String ShowWatches(Model map) {

		return "/product/watches";
	}

	@GetMapping("/maleshoelist")
	public String ShowMenShoeList(Model map) {

		return "/product/maleshoelist";
	}

	@GetMapping("femaleshoelist")
	public String ShowFemaleShoeList(Model map) {

		return "/product/femaleshoelist";
	}

//	-------------------------------------------------------FEATURED IMAGES-------------------------------------------------------------------------------

	@GetMapping("/cloths")
	public String ShowAllCloths(Model map) {

		return "/product/cloths";
	}

	@GetMapping("/shoes")
	public String ShowAllShoes(Model map) {

		return "/product/shoes";
	}

}
