package com.app.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Accounts;
import com.app.pojos.Cart;
import com.app.service.IAccountsService;

@Controller
@RequestMapping("/userRegister")
public class AccountController {

	@Autowired
	private IAccountsService service;

	public AccountController() {
		System.out.println("in cnstr of " + getClass().getName());
	}

	@GetMapping("/register")
	public String showRegisterForm(Accounts a) {
		System.out.println("in show Accounts form ");

		return "/userRegister/register";
	}

	@PostMapping("/register")
	public String processAddRegisterForm(Accounts transientPopulatedAccounts, RedirectAttributes flashMap) {
		System.out.println("in process form " + transientPopulatedAccounts);

		transientPopulatedAccounts.setRole("customer");
		Cart cart = new Cart();
		// flashMap.addFlashAttribute("cartStatus", cartService.addCart(cart));
		transientPopulatedAccounts.setCart(cart);

		flashMap.addFlashAttribute("status", service.addUser(transientPopulatedAccounts));
		return "redirect:/userRegister/login";
	}

	@GetMapping("/login")
	public String showLoginForm(Accounts u) {
		System.out.println("in show login form");
		return "/userRegister/login";
	}

	@PostMapping("/login")
	public String processUserLoginForm(Accounts u, HttpSession session, RedirectAttributes flashMap) {
		System.out.println("in process form " + u);
		Accounts validatedUser = service.validateUser(u);
		if (validatedUser != null) {
			session.setAttribute("userDetails", validatedUser);
			if (validatedUser.getRole().equalsIgnoreCase("admin")) {
				return "redirect:/product/adminview";
			} else {
				return "redirect:/product/customerview";
			}
		}
		String mesg = "Invalid Email or Password, Please try again";
		flashMap.addFlashAttribute("failStatus", mesg);
		return "redirect:/userRegister/login";
	}

	@GetMapping("/logout")
	public String customerLogout(HttpSession session) {
		session.invalidate();
		return "/index";
	}

}
