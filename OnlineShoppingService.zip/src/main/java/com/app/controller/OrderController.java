package com.app.controller;

import java.util.Set;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.app.pojos.Accounts;
import com.app.pojos.OrderDetails;
import com.app.pojos.OrderProduct;
import com.app.service.IOrderDetailsService;

@Controller
@RequestMapping("/order")
public class OrderController {
	@Autowired
	private IOrderDetailsService service;

	@GetMapping("/orderNow")
	public String processOrderNow(HttpSession session, Model map) {
		Accounts u = (Accounts) session.getAttribute("userDetails");
		if (u == null)
			return "/user/login";
		map.addAttribute("orderdetails", new OrderDetails());
		session.setAttribute("orderDetails", new OrderDetails());
		return "/order/custDetails";
	}

	@PostMapping("/orderNow")
	public String processPlaceOrder(@ModelAttribute OrderDetails orderdetails, HttpSession session) {
		Accounts u = (Accounts) session.getAttribute("userDetails");

		if (u == null) {
			return "/user/login";
		}

		orderdetails.setStatus("Pending...");

		System.out.println(orderdetails);
		Set<OrderProduct> productlist = u.getCart().getProducts();
		for (OrderProduct orderProduct : productlist) {
			orderdetails.getProductlist().add(orderProduct);
		}
		session.setAttribute("orderDetails", orderdetails);
		service.addOrderDetails(orderdetails);
		return "redirect:/order/orderSummary";
	}

	@GetMapping("/orderSummary")
	public String showOrderSummary(HttpSession session) {
		return "/order/orderSummary";
	}

	@GetMapping("/payment")
	public String paymentGetway(HttpSession session) {
		return "/order/payment";
	}

	@GetMapping("/thankyou")
	public String thankYou(HttpSession session) {
		return "/order/thankyou";
	}

	@GetMapping("/orderDetails")
	public String showOrderDetails(HttpSession session, Model map) {
		map.addAttribute("OrdetDetails_list", service.getAllProducts());

		return "/order/orderDetails";
	}

	@GetMapping("/myorders")
	public String myOrders(HttpSession session, Model map) {

		Accounts acc = (Accounts) session.getAttribute("userDetails");

		map.addAttribute("myorderlist", service.getOrderDetailsByEmail(acc.getEmail()));
		System.out.println(service.getOrderDetailsByEmail(acc.getEmail()));

		return "/order/myorders";
	}

	@GetMapping("/orderstatus/{id}")
	public String status(@PathVariable int id, HttpSession session, Model map) {
		map.addAttribute("statusOfOrder", service.getOrderDetailsById(id));
		return "/order/orderstatus";
	}

	@GetMapping("/dispatch/{id}")
	public String dispatch(@PathVariable int id, HttpSession session, Model map) {

		OrderDetails od = service.getOrderDetailsById(id);
		service.updateStatus(od);
		return "redirect:/order/orderDetails";
	}

}
