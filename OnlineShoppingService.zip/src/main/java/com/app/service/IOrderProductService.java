package com.app.service;

import com.app.pojos.OrderProduct;

public interface IOrderProductService {
	String addOrderProduct(OrderProduct op);

	OrderProduct getOrderProductDetails(int oprodId);
}
