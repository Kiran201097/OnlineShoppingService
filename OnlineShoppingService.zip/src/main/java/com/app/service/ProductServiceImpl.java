package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IProductDao;
import com.app.pojos.Product;

@Service
@Transactional
public class ProductServiceImpl implements IProductService {

	@Autowired
	private IProductDao dao;

	@Override
	public List<Product> getAllProducts() {

		return dao.getAllProducts();
	}

	@Override
	public String deleteProduct(int propductId) {

		return dao.deleteProduct(propductId);
	}

	@Override
	public String addProduct(Product transientProduct) {

		return dao.addProduct(transientProduct);
	}

	@Override
	public Product getProductDetails(int id) {

		return dao.getProductDetails(id);
	}

	@Override
	public String updateProduct(int id, Product productToUpdate) {
		Product existingProduct = dao.getProductDetails(id);
		existingProduct.setImgUrl(productToUpdate.getImgUrl());
		existingProduct.setPrice(productToUpdate.getPrice());
		existingProduct.setName(productToUpdate.getName());
		existingProduct.setCategory(productToUpdate.getCategory());
		return dao.updateProduct(existingProduct);
	}

	@Override
	public List<Product> getProductsByCategory(String category) {

		return dao.getProductsByCategory(category);
	}

}
