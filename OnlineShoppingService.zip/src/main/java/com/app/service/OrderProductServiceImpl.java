package com.app.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.IOrderProductDao;
import com.app.pojos.OrderProduct;

@Service
@Transactional
public class OrderProductServiceImpl implements IOrderProductService {
	@Autowired
	private IOrderProductDao dao;

	@Override
	public String addOrderProduct(OrderProduct op) {
		return dao.addOrderProduct(op);
	}

	@Override
	public OrderProduct getOrderProductDetails(int oprodId) {
		return dao.getOrderProductDetails(oprodId);
	}

}
