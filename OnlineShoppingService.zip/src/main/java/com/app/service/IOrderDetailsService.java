package com.app.service;

import java.util.List;

import com.app.pojos.OrderDetails;

public interface IOrderDetailsService {
	String addOrderDetails(OrderDetails od);

	OrderDetails getOrderDetailsById(int id);

	List<OrderDetails> getAllProducts();

	String updateStatus(OrderDetails statusToUpdate);

	List<OrderDetails> getOrderDetailsByEmail(String email);
}
