package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.IAccountsDao;
import com.app.pojos.Accounts;

@Service
@Transactional
public class AccountsServiceImpl implements IAccountsService {

	@Autowired
	private IAccountsDao dao;

	@Override
	public Accounts validateUser(Accounts user) {

		return dao.validateUser(user);
	}

	@Override
	public String addUser(Accounts transientAccount) {

		return dao.addUser(transientAccount);

	}

}
