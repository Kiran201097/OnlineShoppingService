package com.app.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.IOrderDetailsDao;
import com.app.pojos.OrderDetails;

@Service
@Transactional
public class OrderDetailsServiceImpl implements IOrderDetailsService {
	@Autowired
	private IOrderDetailsDao dao;

	@Override
	public String addOrderDetails(OrderDetails od) {

		return dao.addOrderDetails(od);
	}

	@Override
	public List<OrderDetails> getAllProducts() {

		return dao.getAllProducts();
	}

	@Override
	public OrderDetails getOrderDetailsById(int id) {

		return dao.getOrderDetailsById(id);
	}

	@Override
	public String updateStatus(OrderDetails statusToUpdate) {
		statusToUpdate.setStatus("Dispatched");
		return dao.updateStatus(statusToUpdate);
	}

	@Override
	public List<OrderDetails> getOrderDetailsByEmail(String email) {

		return dao.getOrderDetailsByEmail(email);
	}
}
