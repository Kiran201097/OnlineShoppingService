package com.app.service;

import com.app.pojos.Accounts;

public interface IAccountsService {
	String addUser(Accounts transientAccount);

	Accounts validateUser(Accounts user);

}
