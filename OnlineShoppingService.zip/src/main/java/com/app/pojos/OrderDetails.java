package com.app.pojos;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "orderdetails")
public class OrderDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String customerName;
	private String address;
	private long contactNumber;
	@Column(name = "orderproductslist")
	@OneToMany(targetEntity = OrderProduct.class)
	private Set<OrderProduct> productlist = new HashSet<OrderProduct>();
	private String totalPrice;
	private String status;
	private String email;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public OrderDetails() {
		System.out.println("in constr " + getClass());
	}

	public OrderDetails(String customerName, String address, long contactNumber, Set<OrderProduct> productlist,
			String totalPrice) {
		super();
		this.customerName = customerName;
		this.address = address;
		this.contactNumber = contactNumber;
		this.productlist = productlist;
		this.totalPrice = totalPrice;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Set<OrderProduct> getProductlist() {
		return productlist;
	}

	public void setProductlist(Set<OrderProduct> productlist) {
		this.productlist = productlist;
	}

	public String getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(String totalPrice) {
		this.totalPrice = totalPrice;
	}

	@Override
	public String toString() {
		return "OrderDetails [id=" + id + ", customerName=" + customerName + ", address=" + address + ", contactNumber="
				+ contactNumber + ", productlist=" + productlist + ", totalPrice=" + totalPrice + "]";
	}

}
